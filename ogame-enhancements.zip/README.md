# OGame Enhancements - Browser Add-On/Extension

Provides various visual improvements to the OGame UI, including de-emphasizing premium dark matter features.

Firefox Add-On: [[link]]()  
Chrome/Edge Extension: [[link]]()

## To-Do

- fix buttons on defense page saying "Improve"
- resource countdowns

## Changelog

### 1.0

- Initial upload