# OGame Enhancements - Browser Add-On/Extension

Provides various visual improvements to the OGame UI, including de-emphasizing premium dark matter features.

Firefox Add-On: [[link]]()  
Chrome/Edge Extension: [[link]]()

## Changelog

### 1.0

- Initial upload